from django import forms
from .models import cncfprofile

class UpdateProfile(forms.ModelForm):
    class meta:
        model = cncfprofile
        fields = []