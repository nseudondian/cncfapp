from django.apps import AppConfig


class CncfprofileConfig(AppConfig):
    name = 'cncfprofile'

def ready(self):
    import cncfprofile.signals