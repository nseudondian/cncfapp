from django.contrib import admin
from .models import cncfprofile

admin.site.register(cncfprofile)
