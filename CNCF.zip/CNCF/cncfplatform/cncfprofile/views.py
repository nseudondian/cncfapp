from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .profile import UpdateProfile
from users.forms import UpdateUser
from django.contrib import messages



@login_required
def profile(request):
    if request.method=='POST':
        u_form = UpdateUser(request.POST, instance=request.user)
        p_form = UpdateProfile(request.POST, request.FILES, instance=request.user.profile)
    if  u_form.is_valid and p_form.is_valid():
        u_form.save()
        p_form.save()
        messages.success(request, f'Your Form is Updated!!!')
        return redirect('profile')
    else:
        u_form = UpdateUser(request.POST, instance=request.user)
        p_form = UpdateProfile(request.POST, instance=request.user.profile)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }
    return render(request, 'cncfprofile/profile.htm', context)
