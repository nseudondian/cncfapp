from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import RegistrationForm

def registration(request):
    if request.method == 'POST':
        forms = RegistrationForm(request.POST)
        if forms.is_valid(): 
            forms.save()
            username = forms.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}')
            return redirect('cncfdata-home')
    else:
        forms = RegistrationForm()


        
    return render (request, 'users/form.htm', {'forms':forms})

