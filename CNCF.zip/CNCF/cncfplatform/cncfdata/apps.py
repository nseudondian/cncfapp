from django.apps import AppConfig


class CncfdataConfig(AppConfig):
    name = 'cncfdata'
